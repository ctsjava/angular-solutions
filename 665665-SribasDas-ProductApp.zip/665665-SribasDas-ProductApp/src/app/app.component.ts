import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  title = 'ProductApp';
  totalPrice=0;
  test(value){
    this.totalPrice = value;
  }
}
