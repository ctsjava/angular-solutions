import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.less']
})
export class ProductComponent implements OnInit {

  constructor() { }
@Input()
  cardHeader:string;
  @Input()
  productName:string;
  @Input()
  price;
@Input() totalNow;
@Output() finalTotal = new EventEmitter();
  btnStatus=true;

  calculateTotal(){
    this.btnStatus=false;
   this.finalTotal.emit(parseInt(this.price) + parseInt(this.totalNow));
  }
  ngOnInit() {
  }

}
