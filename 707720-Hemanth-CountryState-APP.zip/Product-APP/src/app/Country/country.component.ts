import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { APPLICATION_MODULE_PROVIDERS } from '@angular/core/src/application_module';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html'
})
export class CountryComponent implements OnInit {

  constructor() { }

  @Input()
  cardHeader:string;
  @Input()
  productName:string;
  @Input()
  price:number;

  cart=new Array();
  public states: State[] = [{id: 1, countryId:1, name:"AP"},{id: 2, countryId:1, name:"TN"},{id: 3, countryId:2, name:"ARIZONA"},{id: 4, countryId:2, name:"ILLINO"}]; 
  public countries: Country[] = [{id:2, name: "USA"},{id:1, name: "INDIA"}];

  @Output()
  cartProduct=new EventEmitter();

  statesEnabled: boolean;

  btnStatus=true;

 public selectedStates : State[];
 
  onSelect(value){
    this.selectedStates = this.states.filter(state=>(state.countryId == value));
    this.statesEnabled = this.selectedStates.length > 0;
  }

  onStateSelect(value){
    let state = this.states.filter(state=>(state.id == value))[0];
    if (state != null)
    {
    let country = this.countries.filter(country=>(country.id == state.countryId))[0];
    this.cartProduct.emit(state.name + ' , ' + country.name);
    }
    else
    {
      this.cartProduct.emit('');
    }
  }


  ngOnInit() {
  }

}

export interface Country{
  id : number; name: string;
}

export interface State{
  id : number; name: string; countryId: number;
}
