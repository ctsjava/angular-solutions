import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Country n State';

  total:number;
  itemPrice:number;
  cartProducts: string;

  Display(statncountry){
    if(statncountry != '')
    {
      this.cartProducts="You've selected : " + statncountry;
    }
    else
    {
      this.cartProducts = null;
    }
  }
}
