import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountrystatesComponent } from './countrystates.component';

describe('CountrystatesComponent', () => {
  let component: CountrystatesComponent;
  let fixture: ComponentFixture<CountrystatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountrystatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountrystatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
