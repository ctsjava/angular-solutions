import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-countrystates',
  templateUrl: './countrystates.component.html',
  styleUrls: ['./countrystates.component.css']
})
export class CountrystatesComponent implements OnInit {
  
  isCountrySelected: boolean = false;
  selectedCountryName: string;
  selectedStateName: string;

  countries: any = [{id: 'India', name:'India'}, 
                    {id: 'USA', name:'USA'}, 
                    {id: 'UK', name:'United Kingdom'}];
  states: any[] = [];
  @Output()
  selectedCountry = new EventEmitter();
  @Output()
  selectedState = new EventEmitter();

  constructor() { }

  ngOnInit() {
    
  }

  filterStatesByCountry(country){
    this.states = [];
    this.isCountrySelected = true;
      if (country == 'India') {
          this.states.push("Andhra Pradesh", "Assam", "Nagaland", "Orissa", "Pondicherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu");
      } else if (country == 'USA') {
          this.states.push("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia");
      } else if (country == 'UK') {
          this.states.push('South East', 'London', 'North West', 'South West', 'North East');
      } else {
          this.states = [];
          this.isCountrySelected = false;
      }

  }

  onStateChange() {
    this.selectedCountry.emit(this.selectedCountryName);
    this.selectedState.emit(this.selectedStateName);
  }

}
