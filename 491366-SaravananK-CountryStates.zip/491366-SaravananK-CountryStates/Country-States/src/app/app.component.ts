import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Country-States';

  @Input()
  selCountry: string;
  @Input()
  selState: string;

  setCountry(country) {
      this.selCountry = country;
  }

  setState(state) {
      this.selState = state;
  }
}
