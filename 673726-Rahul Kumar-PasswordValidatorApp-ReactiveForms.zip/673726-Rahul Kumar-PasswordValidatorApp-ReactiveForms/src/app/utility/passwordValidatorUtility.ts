import { FormGroup } from '@angular/forms';

export function PasswordValidation(Password: string, ConfPassword: string) {
    return (formGroup: FormGroup) => {
        let password = formGroup.controls[Password];
        let confirmPassword = formGroup.controls[ConfPassword];
        
        if (password.errors && !confirmPassword.errors.matching) {
            return;
        }

        if (password.value !== confirmPassword.value) {
            confirmPassword.setErrors({ matching: true });
        } else {
            confirmPassword.setErrors(null);
        }
    }
}
