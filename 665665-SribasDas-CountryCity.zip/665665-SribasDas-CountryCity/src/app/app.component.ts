import { Component } from '@angular/core';
// import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  title = 'DropDownApp';

  public countries: string[] = ['USA', 'UK', 'Canada'];
countryList: Array<any> = [
    { name: 'Germany', cities: ['Duesseldorf', 'Leinfelden-Echterdingen', 'Eschborn'] },
    { name: 'Spain', cities: ['Barcelona'] },
    { name: 'USA', cities: ['Downers Grove'] },
    { name: 'Mexico', cities: ['Puebla'] },
    { name: 'China', cities: ['Beijing'] },
  ];
  cities: Array<any>;
  changeCountry(count) {
    this.cities = this.countryList.find(con => con.name == count).cities;
  }

    //default: string = 'UK';
//countryForm: FormGroup;

 constructor() {
        // this.countryForm = new FormGroup({
        //     country: new FormControl(null)
        // });
        // this.countryForm.controls['country'].setValue(this.default, {onlySelf: true});
    }

}
