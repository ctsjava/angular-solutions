import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product-APP';
  cartProducts;

  hasProduct1Selected = false;

totalPrice:number = 0;
  updatePrice(cart)
  {
  //  this.careProducts.push(cart.cardHeader);
    this.totalPrice += parseInt(cart.price);
    document.getElementById(cart.id).style.display ="block";
    
  }

  hideMe(ctrl)
  {
    document.getElementById(ctrl).style.display = "none";
    }
}

