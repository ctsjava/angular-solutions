import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  @Input()
  cardId: string;
  @Input()
  cardHeader:string;
  @Input()
  productName:string;
  @Input()
  price:number;


@Input() hasProduct1Selected;

  btnStatus=true;

  calculateTotal(){
    if(this.btnStatus)
    {
      this.btnStatus = false;
      var cart = {
        id:this.cardId,
        cardHeader:this.cardHeader,
        price:this.price
      };
      
      this.changeCartPrice.emit(cart);
    
    }
  else
    {
    this.btnStatus = true;
    var cart = {
        id:this.cardId,
        cardHeader:this.cardHeader,
        price:-this.price
      };
      alert(cart.id)
      this.changeCartPrice.emit(cart);
    }
  }

  removeme()
  {
this.btnStatus = true;
    var cart = {
        id:this.cardId,
        cardHeader:this.cardHeader,
        price:-this.price
      };
      this.changeCartPrice.emit(cart); }

@Output() 
changeCartPrice = new EventEmitter<Array>();




  ngOnInit() {
  }

}


