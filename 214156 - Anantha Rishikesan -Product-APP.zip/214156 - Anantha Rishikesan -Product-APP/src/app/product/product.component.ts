import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  @Input()
  cardHeader:string;
  @Input()
  productName:string;
  @Input()
  price:number;

@Input() hasProduct1Selected;

  btnStatus=true;

  calculateTotal($event){
    if(this.btnStatus)
    {
    this.changeCartPrice.emit(this.price);
    $event.target.innerHTML = 'Remove from cart'
    this.btnStatus = false;
    $event.target.className = 'btn btn-danger';
    }
  else
    {
    this.changeCartPrice.emit(-this.price)   
    $event.target.innerHTML = "Add to cart"
    this.btnStatus = true;
    $event.target.className = "btn btn-success";   
    }
  }

@Output() 
changeCartPrice = new EventEmitter<number>();




  ngOnInit() {
  }

}
