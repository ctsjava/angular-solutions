import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  selectedCountry ="";
  showStates = false;
  Countries = [{"id":"1","countryName":"India"},{"id":"2","countryName":"USA"}];
  
  States: Array<any> = [  
    {"countryId":"1","stateNames":[{"id":"11","stateName":"Chennai"},{"id":"12","stateName":"Delhi"},{"id":"13","stateName":"Mumbai"}]},
    {"countryId":"2","stateNames":[
      {"id":"21","stateName":"Alabama"},
      {"id":"22","stateName":"Alaska"},
      {"id":"23","stateName":"Arizona"},
      {"id":"24","stateName":"California"}
      ]
    }
  ];
  countryStates = [];


  populateStates(value){
    this.showStates = true;
    this.countryStates = this.States.find(c => c.countryId == this.selectedCountry).stateNames;
    console.log(this.selectedCountry);
    console.log(this.countryStates);
  }

}
