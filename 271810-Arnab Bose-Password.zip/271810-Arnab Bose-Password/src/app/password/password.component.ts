import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {


    handleForm(myform: NgForm) {

        console.log(myform.value);
   }
  constructor() { }

  ngOnInit() {
  }

}
