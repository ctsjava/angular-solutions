import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {country} from './country.model';
import {state} from './state.model';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  public isCountrySelected: boolean = false;
  public selectedCountry: number;
  public selectedState: number;
  public countryList: country[] = [];
  public stateList: state[] = [];
  public selectedStateList: state[] = [];


  constructor() { }
  @Output()
  parentMsg = new EventEmitter<Object>();

  ngOnInit() {
    this.countryList.push({"countryId":1, "countryName":"India"},{"countryId":2, "countryName":"USA"}
    );

    this.stateList.push(
      {"countryId":1,"stateId":9, "stateName":"Tamil Nadu"},
    {"countryId":1,"stateId":1, "stateName":"Kerala"},
    {"countryId":1,"stateId":2, "stateName":"Karnataka"},
    {"countryId":1,"stateId":3, "stateName":"AndraPradesh"},
    {"countryId":1,"stateId":4, "stateName":"Gujarat"},
{"countryId":1,"stateId":5, "stateName":"Punjab"},
{"countryId":1,"stateId":6, "stateName":"Haryana"},
{"countryId":1,"stateId":7, "stateName":"Orissa"},
{"countryId":1,"stateId":8, "stateName":"J&K"},
{"countryId":1,"stateId":9, "stateName":"Madhya Pradesh"},
    {"countryId":2,"stateId":100, "stateName":"Tenessesse"},
    {"countryId":2,"stateId":200, "stateName":"New York"},
    {"countryId":2,"stateId":300, "stateName":"LogAngels"},
    {"countryId":2,"stateId":400, "stateName":"Texas"},
    {"countryId":2,"stateId":400, "stateName":"Ohio"}
    );
  }

  emitToParent() {
    this.parentMsg.emit("Selected Country : "+ this.countryList.filter(x=>x.countryId==this.selectedCountry)[0].countryName + 
    " & SelectedState : "+    this.selectedStateList.filter(x=>x.stateId==this.selectedState)[0].stateName);
  }

  onCountryChange(selectedvalue: number): void {
    this.selectedState=0;
    if (selectedvalue == 0) {
      this.isCountrySelected = false;
    }
    else {
      this.isCountrySelected = true;
    }
this.selectedStateList=this.stateList.filter(x=>x.countryId==this.selectedCountry);
this.parentMsg.emit("Selected Country: "+ this.countryList.filter(x=>x.countryId==this.selectedCountry)[0].countryName + 
" | SelectedState: "+    " ");
  }
}
