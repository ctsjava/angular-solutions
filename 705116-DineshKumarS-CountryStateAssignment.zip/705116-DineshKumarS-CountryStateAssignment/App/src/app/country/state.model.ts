

export class state {
  countryId: number;
  stateId: number;
  stateName: string;
}