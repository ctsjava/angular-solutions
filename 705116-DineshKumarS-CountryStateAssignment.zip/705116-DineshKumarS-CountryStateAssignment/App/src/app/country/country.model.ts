
export class country {
  countryId: number;
  countryName: string;
}