import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {
  public countries: country[] = [];
  public states: state[] = [];
  public filteredStates: state[] = [];

  public isCountrySelected: boolean = false;
  public selectedCountry: number;
  public selectedState: number;

  constructor() { }
  @Output()
  parentMsg = new EventEmitter<Object>();

  ngOnInit() {
    this.countries.push({"countryId":1, "countryName":"India"}, {"countryId":2, "countryName":"USA"});   

    this.states.push(
    {"stateId":1, "countryId":1, "stateName":"TamilNadu"},
    {"stateId":2, "countryId":1, "stateName":"Kerala"},
    {"stateId":3, "countryId":1, "stateName":"AndraPradesh"},
    {"stateId":4, "countryId":1, "stateName":"Telangana"},
    {"stateId":5, "countryId":1, "stateName":"Karnataka"},
    {"stateId":6, "countryId":2, "stateName":"Alabama"},
    {"stateId":7, "countryId":2, "stateName":"New York"},
    {"stateId":8, "countryId":2, "stateName":"California"},
    {"stateId":9, "countryId":2, "stateName":"Texas"},
    {"stateId":10, "countryId":2, "stateName":"Washington"}
    );
  }

  showMessage() {
    this.parentMsg.emit("Selected Country: "+ this.countries.filter(x => x.countryId == this.selectedCountry)[0].countryName + " | SelectedState: "+    this.filteredStates.filter(x => x.stateId == this.selectedState)[0].stateName);
  }

  changeCountry(countryId: number): void {
    this.selectedState = 0;
    if (countryId == 0) {
      this.isCountrySelected = false;
    }
    else {
      this.isCountrySelected = true;
    }
    this.filteredStates = this.states.filter(x => x.countryId == this.selectedCountry);
    this.parentMsg.emit("Selected Country: "+ this.countries.filter(x => x.countryId == this.selectedCountry)[0].countryName + " | SelectedState: "+    " ");
  }
}

export class country {
  countryId: number;
  countryName: string;
}

export class state {
  countryId: number;
  stateId: number;
  stateName: string;
}