import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {
  public countryList: country[] = [];
  public stateList: state[] = [];
  public selectedStateList: state[] = [];

  public isCountrySelected: boolean = false;
  public selectedCountry: number;
  public selectedState: number;
  public msg: string;

  constructor() { }
  @Output()
  parentMsg = new EventEmitter<Object>();

  ngOnInit() {
    this.countryList.push({"countryId":1, "countryName":"India"},{"countryId":2, "countryName":"USA"}
    );

    this.stateList.push({"countryId":1,"stateId":9, "stateName":"Karnataka"},
    {"countryId":1,"stateId":1, "stateName":"Kerala"},
    {"countryId":1,"stateId":2, "stateName":"TamilNadu"},
    {"countryId":1,"stateId":3, "stateName":"AndraPradesh"},
    {"countryId":1,"stateId":4, "stateName":"Telangana"},
    {"countryId":2,"stateId":5, "stateName":"Alabama"},
    {"countryId":2,"stateId":6, "stateName":"New York"},
    {"countryId":2,"stateId":7, "stateName":"California"},
    {"countryId":2,"stateId":8, "stateName":"Texas"}
    );
  }

  responseBack() {
    this.parentMsg.emit("Selected Country: "+ this.countryList.filter(x=>x.countryId==this.selectedCountry)[0].countryName + " | SelectedState: "+    this.selectedStateList.filter(x=>x.stateId==this.selectedState)[0].stateName);

  }

  onCountryChange(selectedvalue: number): void {
    this.SelectedState=0;
    if (selectedvalue == 0) {
      this.isCountrySelected = false;
    }
    else {
      this.isCountrySelected = true;
    }
this.selectedStateList=this.stateList.filter(x=>x.countryId==this.selectedCountry);
this.parentMsg.emit("Selected Country: "+ this.countryList.filter(x=>x.countryId==this.selectedCountry)[0].countryName + " | SelectedState: "+    " ");
  }
}

export class country {
  countryId: number;
  countryName: string;
}

export class state {
  countryId: number;
  stateId: number;
  stateName: string;
}