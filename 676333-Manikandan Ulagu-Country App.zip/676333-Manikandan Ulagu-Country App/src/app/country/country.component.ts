import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {
  public countries: country[] = [];
  public states: state[] = [];
  public filteredStates: state[] = [];

  public isCountrySelected: boolean = false;
  public selectedCountry: number;
  public selectedState: number;

  constructor() { }
  @Output()
  parentMsg = new EventEmitter<Object>();

  ngOnInit() {
    this.countries.push({"countryId":1, "countryName":"India"}, {"countryId":2, "countryName":"United States"} , {"countryId":3, "countryName":"England"});   

    this.states.push(
    {"stateId":1, "countryId":1, "stateName":"TamilNadu"},
    {"stateId":2, "countryId":1, "stateName":"Maharastra"},
    {"stateId":3, "countryId":1, "stateName":"Kashmir"},
    {"stateId":4, "countryId":1, "stateName":"Telangana"},
    {"stateId":5, "countryId":1, "stateName":"Karnataka"},
    {"stateId":6, "countryId":2, "stateName":"New Jersey"},
    {"stateId":7, "countryId":2, "stateName":"Virginia"},
    {"stateId":8, "countryId":2, "stateName":"California"},
    {"stateId":9, "countryId":2, "stateName":"Indiana"},
    {"stateId":10, "countryId":2, "stateName":"Tennessee"},
    {"stateId":11, "countryId":3, "stateName":"London"},
    {"stateId":12, "countryId":3, "stateName":"Liverpool"},
    {"stateId":13, "countryId":3, "stateName":"Manchester"},
    {"stateId":14, "countryId":3, "stateName":"Oxford"},
    {"stateId":15, "countryId":3, "stateName":"Preston"}
    );
  }

  showMessage() {
    this.parentMsg.emit("Country: "+ this.countries.find(x => x.countryId == this.selectedCountry).countryName + " | State : "+    this.filteredStates.find(x => x.stateId == this.selectedState).stateName);
  }

  changeCountry(countryId: number): void {
    this.selectedState = 0;
    if (countryId == 0) {
      this.isCountrySelected = false;
    }
    else {
      this.isCountrySelected = true;
    }
    this.filteredStates = this.states.filter(x => x.countryId == this.selectedCountry);
    this.parentMsg.emit("Country: "+ this.countries.find(x => x.countryId == this.selectedCountry).countryName + " | State: "+    " ");
  }
}

export class country {
  countryId: number;
  countryName: string;
}

export class state {
  countryId: number;
  stateId: number;
  stateName: string;
}