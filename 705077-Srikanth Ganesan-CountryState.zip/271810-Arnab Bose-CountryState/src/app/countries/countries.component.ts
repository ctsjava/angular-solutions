import { Component, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-countries',
  templateUrl: './countries.component.html',
  styleUrls: ['./countries.component.css']
})
export class CountriesComponent implements OnInit {
    country: string;
    state: string;
    selectedCountryVal: string;
    selectedStateVal: string;
    //countries: country[] = [{ id: 'USA', name: 'USA' }, { id: 'India', name: 'India' }];
    countries = new Array('India', 'USA', 'UK');
    states = new Array();
    @Output()
    selectedCountry = new EventEmitter();
    @Output()
    selectedState = new EventEmitter();
    
  constructor() { }

  ngOnInit() {
  }

  filterCountries(country) {      
      this.states = [];
      if (country == 'India') {
          this.states.push('West Bengal', 'Maharastra', 'Tamilnadu');
      } else if (country == 'USA') {
          this.states.push('Illinois', 'New York', 'California');
      } else if (country == 'UK') {
          this.states.push('Buckinghamshire', 'Cambridgeshire', 'Hampshire');
      } else {
          this.states = [];
      }
  }

  filterStates(state) {
      this.selectedCountry.emit(this.selectedCountryVal);
      this.selectedState.emit(this.selectedStateVal);
  }
 
   

}
