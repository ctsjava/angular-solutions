import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product-APP';

  total = 0;
  itemPrice;
  itemName;
  cartProducts = new Array();  

  cartData(product) {
    this.itemPrice = product[1];
    this.itemName = product[0];
    this.total = (this.total) + parseInt(this.itemPrice);
    this.cartProducts.push(this.itemName + ',' + this.itemPrice);
  }

  removeItem(item){    
    this.total = (this.total) - parseInt(item.split(",").pop());  
    this.cartProducts.splice(this.cartProducts.indexOf(item), 1);        
  }
}
