import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryStateFormComponent } from './country-state-form.component';

describe('CountryStateFormComponent', () => {
  let component: CountryStateFormComponent;
  let fixture: ComponentFixture<CountryStateFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountryStateFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryStateFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
