import { Component, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-country-state-form',
  templateUrl: './country-state-form.component.html',
  styleUrls: ['./country-state-form.component.css']
})
export class CountryStateFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

@Output() parentMsg=new EventEmitter();




  selectedCountry = 0;
  selectedState = 0;
  selectedCountryText = '';
  selectedStateText = '';
  selectedMsg = '';
  title = 'app';
  states = [];
  cities = [];

  onSelectCountry(country_id: number, country_name: string) {
   console.log(country_name);
    this.selectedCountry = country_id;
    this.selectedCountryText = country_name;
    this.selectedState = 0;
    this.cities = [];
    this.parentMsg.emit('');
    this.states = this.getStates().filter((item) => {
      return item.country_id === Number(country_id)
    });
  }

    onSelectState(state_name: string) {
    this.selectedStateText = state_name;
      this.selectedMsg=this.selectedCountryText + ' - ' + this.selectedStateText; 
    console.log(this.selectedMsg)
    this.parentMsg.emit(this.selectedMsg);
    
  }


  getCountries() {
    return [
      { id: 1, name: 'India' },
      { id: 2, name: 'USA' },
      { id: 3, name: 'UK' }
    ];
  }

  getStates() {
    return [
      { id: 1, country_id: 1, name: 'Tamil Nadu' },
      { id: 2, country_id: 1, name: 'Kerala' },
      { id: 3, country_id: 2, name: 'Illinois' },
      { id: 4, country_id: 2, name: 'Pensylvania' },
      { id: 5, country_id: 3, name: 'Hampshire' },
      { id: 6, country_id: 3, name: 'Yorkshore' },
    ]
  }

 
}






