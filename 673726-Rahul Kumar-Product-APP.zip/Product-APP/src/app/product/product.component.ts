import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Output()
  itemPrice : EventEmitter<number>;

  @Output()
  removePrice : EventEmitter<number>;

  constructor() {
    this.itemPrice = new EventEmitter();
    this.removePrice = new EventEmitter();
   }

  @Input()
  cardHeader:string;
  @Input()
  productName:string;
  @Input()
  price:number;

  btnStatus=true;

  calculateTotal(){
    this.btnStatus=false;
    this.itemPrice.emit(this.price);
  }

  removeItem () {
    this.btnStatus=true;
    this.removePrice.emit(this.price);

  }

  ngOnInit() {
  }

}
