import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product-APP';

  price = 0;

  calculatePrice(itemPrice) {
    this.price += parseInt(itemPrice);
  }

  removeItem(itemPrice) {
    this.price -= parseInt(itemPrice);
  }
}
