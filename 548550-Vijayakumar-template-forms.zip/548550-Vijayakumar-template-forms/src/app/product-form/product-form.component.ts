import { Component, OnInit, ɵConsole } from '@angular/core';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

	selectedCountry;
	selectedState;
	isEnabled;
	state;
	
	country:Array<Object> = [
		{id: 0, name: "AUSTRALIA"},
		{id: 1, name: "INDIA"},
		{id: 3, name: "USA"}
	];
	
	stateAustralia:Array<Object> = [
		{id: 0, name: "New South Wales"},
		{id: 1, name: "Queensland"},
		{id: 2, name: "Victoria"}
	];
	
	stateIndia:Array<Object> = [
		{id: 0, name: "Mumbai"},
		{id: 1, name: "Chennai"},
		{id: 2, name: "Delhi"},
		{id: 3, name: "Kolkata"},
		{id: 4, name: "Hyderabad"}
	];
	
	stateUsa:Array<Object> = [
		{id: 0, name: "Chicago"},
		{id: 1, name: "New York"},
		{id: 2, name: "Texas"},
		{id: 3, name: "Cleveland"}
	];
	
	
	selected(){
		if(this.selectedCountry && this.selectedCountry!='')
		{	
			this.selectedState='';
			this.isEnabled=true;
			console.log(this.selectedCountry.name);
			if(this.selectedCountry.name == 'INDIA')
			{
				this.state=this.stateIndia;
			}
			else if(this.selectedCountry.name == 'AUSTRALIA')
			{
				this.state=this.stateAustralia;
			}
			else if(this.selectedCountry.name == 'USA')
			{
				this.state=this.stateUsa;
			}
		}
	}
	
	stateSelected(){console.log(this.selectedState.name)}
	
	ngOnInit() {}

}
