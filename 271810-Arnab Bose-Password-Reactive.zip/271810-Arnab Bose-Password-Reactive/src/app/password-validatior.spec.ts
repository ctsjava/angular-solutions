import { PasswordValidatior } from './password-validatior';

describe('PasswordValidatior', () => {
  it('should create an instance', () => {
    expect(new PasswordValidatior()).toBeTruthy();
  });
});
