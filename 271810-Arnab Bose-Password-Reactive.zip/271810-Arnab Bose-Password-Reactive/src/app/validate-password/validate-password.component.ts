import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { PasswordValidatior } from '../password-validatior';

@Component({
  selector: 'app-validate-password',
  templateUrl: './validate-password.component.html',
  styleUrls: ['./validate-password.component.css']
})
export class ValidatePasswordComponent implements OnInit {

    passValFormGroup: FormGroup;
    passwordFormGroup: FormGroup;

    constructor(private formBuilder: FormBuilder) {
        this.passwordFormGroup = this.formBuilder.group({
            password: ['', Validators.required],
            repeatPassword: ['', Validators.required]
        }, {
                validator: PasswordValidatior.validate.bind(this)
            });
        this.passValFormGroup = this.formBuilder.group({
            passwordFormGroup: this.passwordFormGroup
        });
    }

  ngOnInit() {
    }

  handleForm() {
      alert("Registered");
  }

}
