import {FormGroup} from '@angular/forms';
export class PasswordValidatior {
    static validate(passValFormGroup: FormGroup) {
        let password = passValFormGroup.controls.password.value;
        let repeatPassword = passValFormGroup.controls.repeatPassword.value;

        if (repeatPassword.length <= 0) {
            return null;
        }

        if (repeatPassword !== password) {
            return {
                doesMatchPassword: true
            };
        }

        return null;

    }
}
