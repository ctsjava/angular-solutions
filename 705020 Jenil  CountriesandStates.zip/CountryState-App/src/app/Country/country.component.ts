import { Component,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'countries',
  templateUrl: './country.component.html'
  
})
export class CountryComponent 
{
 
  public countries : Country[] = [{id:1 ,name:'USA'},
  {id:2,name:'India'},{id:3,name:'Germany'}
  ];
  public states : MasterStates[];
  @Output() emiter = new EventEmitter<string>(); 
  public showstates : boolean = false; 
  public masterstates : MasterStates[] = [{id:1,stateid:1, name :'California' }
  ,{id:1,stateid:2,name:'Texas'}, {id:1,stateid:3,name:'Florida'},
  {id:2,stateid:4, name:'Tamilnadu'},{id:2,stateid:5,name:'Karnataka'},
  {id:3,stateid:6,name:'Hamburg'},{id:3,stateid:7,name:'Bremen'}];

  
   public changecountry(value)
   {       
      this.states = this.masterstates.filter(state => (state.id == value));
      this.showstates = this.states.length > 0;      
   }   
  
   public changestate(value)
   {
     if(value > 0)
     {
         var selectstate : MasterStates = this.masterstates.filter(state => (state.stateid == value))[0];
         var selectcountry : Country = this.countries.filter(country => (country.id = selectstate.id))[0];
         var emitText = selectstate.name + ", " +  selectcountry.name;
         this.emiter.emit(emitText);
     }
    
     console.log(this.masterstates.filter(state => (state.stateid == value))[0].name);
   }
}

export interface Country
{
   id:number;
   name:string;
}

export interface MasterStates
{
    id:number;
    stateid:number;
    name:string;

}