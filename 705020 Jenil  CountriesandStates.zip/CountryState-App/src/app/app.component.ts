import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Countries and States-APP';
  public countryandstate : string = ""; 
  public changedText(value:string)
  {
    alert();
     this.countryandstate = value;
  }
}
