import { Component, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-state-comp',
  templateUrl: './state-comp.component.html',
  styleUrls: ['./state-comp.component.css']
})
export class StateCompComponent implements OnInit {

  selectStatus = false;
  countryArray: string[];
  usaStatesArray: string[];
  ukStateArray : string[];
  indStateArray : string[];
  stateArray : string[];

  constructor() { 
     this.countryArray = ['IND','USA','UK'];
     this.usaStatesArray = ['California','Florida','Texas'];
     this.ukStateArray = ['Bristol','Cambridge','Chester'];
     this.indStateArray = ['Jharkhand','West Bengal','UP'];
     
  }
  getCountryValue(value){
    this.selectStatus = true;
    console.log(value);
    if(value == 'USA') {
      this.stateArray = this.usaStatesArray;
    }
    if(value == 'UK') {
      this.stateArray = this.ukStateArray;
    }
    if(value == 'IND') {
      this.stateArray = this.indStateArray;
    }
    
  }

  ngOnInit() {
  }
}
