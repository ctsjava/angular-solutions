import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateCompComponent } from './state-comp.component';

describe('StateCompComponent', () => {
  let component: StateCompComponent;
  let fixture: ComponentFixture<StateCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
